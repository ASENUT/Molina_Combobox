package ventanas;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DatosGenerales extends javax.swing.JFrame {

    private String indexTabla = "";

    public DatosGenerales() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtBusqueda = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnEliminar = new javax.swing.JMenu();
        btnEditar = new javax.swing.JMenu();
        btnCargar = new javax.swing.JMenu();
        btnRegistro = new javax.swing.JMenu();
        btnRegistroCliente = new javax.swing.JMenuItem();
        btnRegistroNutricional = new javax.swing.JMenuItem();
        btnRegistroCosmetologico = new javax.swing.JMenuItem();
        btnRegresar = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("DatosGenerales"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cedula", "Nombre", "Apellido", "Tratamiento", "Sesión", "Costo"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 570, 140));

        txtBusqueda.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        txtBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBusquedaKeyPressed(evt);
            }
        });
        getContentPane().add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, 240, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Apellido o Cédula");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 120, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 250));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Delete.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEliminar);

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Edit.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEditar);

        btnCargar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnCargar.setText("Cargar");
        btnCargar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCargarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnCargar);

        btnRegistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Report.png"))); // NOI18N
        btnRegistro.setText("Registro");

        btnRegistroCliente.setText("Cliente");
        btnRegistroCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistroClienteMouseClicked(evt);
            }
        });
        btnRegistro.add(btnRegistroCliente);

        btnRegistroNutricional.setText("Nutricional");
        btnRegistroNutricional.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistroNutricionalMouseClicked(evt);
            }
        });
        btnRegistro.add(btnRegistroNutricional);

        btnRegistroCosmetologico.setText("Cosmetológico");
        btnRegistroCosmetologico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistroCosmetologicoMouseClicked(evt);
            }
        });
        btnRegistro.add(btnRegistroCosmetologico);

        jMenuBar1.add(btnRegistro);

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnRegresar);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresarMouseClicked
        // TODO add your handling code here:
        if (Interfaz.tipousu.equalsIgnoreCase("Administrador")) {
            MenuAdministrativo to = new MenuAdministrativo();
            to.setVisible(true);
            this.setVisible(false);
        } else if (Interfaz.tipousu.equalsIgnoreCase("Empleado")) {
            MenuEmpleado to = new MenuEmpleado();
            to.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresarMouseClicked

    private void btnRegistroNutricionalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroNutricionalMouseClicked
        // TODO add your handling code here:
        RegistroNutricional rn = new RegistroNutricional(indexTabla);
        rn.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegistroNutricionalMouseClicked

    private void btnRegistroCosmetologicoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroCosmetologicoMouseClicked
        // TODO add your handling code here:
        RegistroCosmetologico rc = new RegistroCosmetologico(indexTabla);
        rc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegistroCosmetologicoMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // CARGAMOS TABLA
        //SELECT P.CEDULA, P.NOM_PAC, P.APE_PAC, TP.NOM_TRATA FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TP WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TP.COD_TRATAMIENTO;
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Estado Civil");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, EC.NOM_ESTADO FROM PACIENTE P, ESTADO_CIVIL EC WHERE P.COD_ESTADO = EC.COD_ESTADO");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowActivated

    private void btnCargarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCargarMouseClicked
        // TODO add your handling code here:
        // CARGAMOS TABLA
        //SELECT P.CEDULA, P.NOM_PAC, P.APE_PAC, TP.NOM_TRATA FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TP WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TP.COD_TRATAMIENTO;
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Estado Civil");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, EC.NOM_ESTADO FROM PACIENTE P, ESTADO_CIVIL EC WHERE P.COD_ESTADO = EC.COD_ESTADO");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnCargarMouseClicked

    private void txtBusquedaKeyPressed(java.awt.event.KeyEvent evt) {
        // TODO add your handling code here:
        // TODO add your handling code here:
        search();
    }

    void search() {
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            //dtm.addColumn("CÃ©dula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Nombre");
            dtm.addColumn("Estado Civil");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            String query = "SELECT DISTINCT P.CEDULA,"
                    + " P.APE_PAC,"
                    + " P.NOM_PAC,"
                    + " EC.NOM_ESTADO"
                    + " FROM PACIENTE P,"
                    + " ESTADO_CIVIL EC"
                    + " WHERE P.COD_ESTADO = EC.COD_ESTADO"
                    + " AND ( P.CEDULA LIKE '" + txtBusqueda.getText() + "%'"
                    + " OR P.APE_PAC LIKE '" + txtBusqueda.getText() + "%' )";
            rs = ventanas.Conexion.link.createStatement().executeQuery(query);
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();
        int col = jTable1.getSelectedColumn();
        String nombre = (String) jTable1.getModel().getValueAt(row, 0);;
        indexTabla = nombre;
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        // TODO add your handling code here:
        if (indexTabla.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione el registro que desea eliminar");
        } else {
            int ax = JOptionPane.showConfirmDialog(null, "¿Desea elimniar la siguiente cédula : " + indexTabla + " ?");
            if (ax == JOptionPane.YES_OPTION) {
                try {
                    int i = ventanas.Conexion.link.createStatement().executeUpdate("DELETE FROM PACIENTE "
                            + " WHERE CEDULA='" + indexTabla + "'");
                    if (i == 1) {
                        JOptionPane.showMessageDialog(null, "Se elimino correctamente" + indexTabla);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "No se puede eliminar el registo debido a que tiene tratamiento realizados");
                    Logger.getLogger(DatosGenerales.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (ax == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "Has seleccionado NO.");
            }
            indexTabla = "";
        }
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseClicked
        if (indexTabla.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione el registro que desea Editar");
        } else {
            int ax = JOptionPane.showConfirmDialog(null, "¿Desea editar la siguiente cédula : " + indexTabla + " ?");
            if (ax == JOptionPane.YES_OPTION) {
                RegistroCliente rc = new RegistroCliente(indexTabla);
                rc.setVisible(true);
                this.dispose();
            } else if (ax == JOptionPane.NO_OPTION) {
                indexTabla = "";
            }
        }
    }//GEN-LAST:event_btnEditarMouseClicked

    private void btnRegistroClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroClienteMouseClicked
        // TODO add your handling code here:
        RegistroCliente rc = new RegistroCliente("");
        rc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegistroClienteMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DatosGenerales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DatosGenerales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DatosGenerales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DatosGenerales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DatosGenerales().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnCargar;
    private javax.swing.JMenu btnEditar;
    private javax.swing.JMenu btnEliminar;
    private javax.swing.JMenu btnRegistro;
    private javax.swing.JMenuItem btnRegistroCliente;
    private javax.swing.JMenuItem btnRegistroCosmetologico;
    private javax.swing.JMenuItem btnRegistroNutricional;
    private javax.swing.JMenu btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
