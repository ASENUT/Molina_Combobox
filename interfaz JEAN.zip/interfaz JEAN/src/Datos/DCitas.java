/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author MASTER
 */
public class DCitas {
    public String HoraCita;
    public String FechaCita;
    public String Cliente;
    public String TipoCita;
    public String Sesiones;
    public String Tratamiento;
    public int COD_Horario;

    public DCitas(){
        
    }
    public int getCOD_Horario() {
        return COD_Horario;
    }

    public void setCOD_Horario(int COD_Horario) {
        this.COD_Horario = COD_Horario;
    }
    public String getTratamiento() {
        return Tratamiento;
    }

    public void setTratamiento(String Tratamiento) {
        this.Tratamiento = Tratamiento;
    }

    public String getSesiones() {
        return Sesiones;
    }

    public void setSesiones(String Sesiones) {
        this.Sesiones = Sesiones;
    }
    
    public DCitas(String HoraCita, String FechaCita, String Cliente, String TipoCita) {
        this.HoraCita = HoraCita;
        this.FechaCita = FechaCita;
        this.Cliente = Cliente;
        this.TipoCita = TipoCita;
    }

    
    public String getHoraCita() {
        return HoraCita;
    }

    public void setHoraCita(String HoraCita) {
        this.HoraCita = HoraCita;
    }

    public String getFechaCita() {
        return FechaCita;
    }

    public void setFechaCita(String FechaCita) {
        this.FechaCita = FechaCita;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }

    public String getTipoCita() {
        return TipoCita;
    }

    public void setTipoCita(String TipoCita) {
        this.TipoCita = TipoCita;
    }
    
    
}
